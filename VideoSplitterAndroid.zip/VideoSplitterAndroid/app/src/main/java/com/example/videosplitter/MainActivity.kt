package com.example.videosplitter

import android.app.Activity
import android.content.Intent
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.view.ViewGroup
import android.widget.*
import java.nio.ByteBuffer
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private var source: Uri? = null
    private var outputFolder: Uri? = null
    private lateinit var status: TextView
    private lateinit var start: Button
    private lateinit var spinner: Spinner
    private lateinit var custom: EditText
    private val ui = Handler(Looper.getMainLooper())
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 48, 28, 20) }
        fun add(v: android.view.View) { layout.addView(v, ViewGroup.LayoutParams(-1, -2)) }
        add(TextView(this).apply { text = "Video Splitter"; textSize = 26f })
        add(Button(this).apply { text = "1. Choose video"; setOnClickListener { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="video/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 1) } })
        add(Button(this).apply { text = "2. Choose output folder"; setOnClickListener { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 2) } })
        add(TextView(this).apply { text = "3. Split duration" })
        spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("1 minute", "2 minutes", "3 minutes", "5 minutes", "7 minutes", "Custom"))
        spinner.setSelection(2); add(spinner)
        custom = EditText(this).apply { hint="Custom minutes (if selected)"; inputType=2 }; add(custom)
        start = Button(this).apply { text="4. Split and save"; setOnClickListener { runSplit() } }; add(start)
        status = TextView(this).apply { text="Choose a video and an output folder."; textSize=16f }; add(status)
        add(TextView(this).apply { text="Note: Cuts follow video keyframes, so each part may be slightly longer than selected. Original audio/video are copied without re-encoding. Supported files depend on device codecs." })
        setContentView(ScrollView(this).apply { addView(layout) })
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or if (requestCode==2) Intent.FLAG_GRANT_WRITE_URI_PERMISSION else 0)
        if(requestCode==1) source=uri else outputFolder=uri
        status.text = if(requestCode==1) "Video selected. Now choose output folder." else "Folder selected. Ready."
    }
    private fun runSplit() {
        val video=source; val folder=outputFolder
        if(video==null || folder==null) { status.text="Select both video and folder."; return }
        val mins = when(spinner.selectedItemPosition) { 0->1.0;1->2.0;2->3.0;3->5.0;4->7.0;else->custom.text.toString().toDoubleOrNull() ?: 0.0 }
        if(mins<=0.0 || mins>10000) { status.text="Enter a valid duration.";return }
        start.isEnabled=false
        thread {
            try { split(video, folder, (mins*60_000_000).toLong()); ui.post { status.text="Finished. Check the selected folder." } }
            catch(e:Exception) { ui.post { status.text="Error: ${e.message}" } }
            finally { ui.post { start.isEnabled=true } }
        }
    }
    private fun split(uri:Uri, folder:Uri, segmentUs:Long) {
        val ex=MediaExtractor()
        try {
            contentResolver.openFileDescriptor(uri,"r")!!.use { ex.setDataSource(it.fileDescriptor) }
            val formats=mutableListOf<MediaFormat>(); val trackMap=mutableMapOf<Int,Int>()
            var videoTrack=-1; var maxSize=1024*1024
            for(i in 0 until ex.trackCount) {
                val f=ex.getTrackFormat(i); val mime=f.getString(MediaFormat.KEY_MIME) ?: ""
                if(mime.startsWith("video/") || mime.startsWith("audio/")) {
                    if(mime.startsWith("video/") && videoTrack<0) videoTrack=i
                    formats.add(f); trackMap[i]=formats.size-1; ex.selectTrack(i)
                    if(f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) maxSize=maxOf(maxSize,f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE))
                }
            }
            if(videoTrack<0) throw IllegalArgumentException("No video track")
            val buffer=ByteBuffer.allocateDirect(maxSize.coerceAtMost(32*1024*1024))
            val info=MediaCodec.BufferInfo()
            var muxer:MediaMuxer?=null; var fd:android.os.ParcelFileDescriptor?=null
            var index=0; var baseUs=0L; var nextUs=segmentUs
            fun openPart() {
                index++
                val parent=DocumentsContract.buildDocumentUriUsingTree(folder,DocumentsContract.getTreeDocumentId(folder))
                val file=DocumentsContract.createDocument(contentResolver,parent,"video/mp4","Part_%03d.mp4".format(index)) ?: error("Could not create output file")
                fd=contentResolver.openFileDescriptor(file,"rw") ?: error("Could not open output")
                muxer=MediaMuxer(fd!!.fileDescriptor,MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                formats.forEach { muxer!!.addTrack(it) }
                muxer!!.start()
                ui.post { status.text="Saving part $index..." }
            }
            fun closePart() { muxer?.stop(); muxer?.release(); muxer=null; fd?.close();fd=null }
            try {
                while(true) {
                    val track=ex.sampleTrackIndex; if(track<0) break
                    val t=ex.sampleTime; if(t<0) break
                    // Start a new part only at a video sync sample. No samples are discarded.
                    if(muxer==null) { baseUs=t; nextUs=t+segmentUs; openPart() }
                    if(track==videoTrack && t>=nextUs && (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC)!=0) {
                        closePart(); baseUs=t; nextUs=t+segmentUs; openPart()
                    }
                    buffer.clear()
                    val n=ex.readSampleData(buffer,0)
                    if(n<0) break
                    info.set(0,n,(t-baseUs).coerceAtLeast(0L),if((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC)!=0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                    muxer!!.writeSampleData(trackMap[track]!!,buffer,info)
                    ex.advance()
                }
            } finally { closePart() }
            if(index==0) throw IllegalArgumentException("No video samples")
        } finally { ex.release() }
    }
}
